import usocket as socket
import network

class WifiServer():
    def __init__(self):
        self.server_setup()
        
    def server_setup(self):
        self.wlan = network.WLAN(network.STA_IF)
        print('setting up wifi server, is wifi active:', self.wlan.active())
        if not self.wlan.isconnected():
                self.reconnect()
#         with open('wifi_server_password.txt') as f:
#             self.password = f.read().strip()
        self.server_ip = self.wlan.ifconfig()[0]
        print('server IP address:', self.server_ip)
        self.server_port = 1704
        self.addr = socket.getaddrinfo(self.server_ip, self.server_port)[0][-1]
        self.server_socket = socket.socket()
        self.server_socket.bind(self.addr)
        self.server_socket.setblocking(True)
        self.server_socket.settimeout(600)
        network.hostname('watchdog0')

        print('wifi server setup complete')

    def reconnect(self):
        print('wifi not connected, checking again and trying to reconnect')
        # wait and check for wifi connection 5 times with wait time of 1 second
        for i in range(5):
            if self.wlan.isconnected():
                return
            else:
                time.sleep_ms(1000)
                print('wifi not connected, trying again')
        # restart machine to rescan wireless networks and reconnect
        machine.reset()

    def start_server(self):
        self.server_socket.listen(1)
        print('Server is started, listening on port', self.server_port)
        while True:   # define periodic check for wifi connection, and contingency if not
            if not self.wlan.isconnected():
                self.reconnect()
            try:
                client_socket, client_address = self.server_socket.accept()
            except Exception:
                print('wifi server timed out, restarting')
                continue
            print("Accepted connection from", client_address)
            input_data = client_socket.recv(256)
            if not input_data:
                print('got None input')
                input_data = ''
            else:
                print('got non-None input')
                input_data = input_data.decode() # receive data from client
            print(f'received from client: {input_data}')
            if input_data == '':
                print('got empty string, sending IMA')
                # send an IMA
                client_socket.send('I am alive'.encode())
            else:
                print('got nonempty string, sending ECHO')
                # echo all caps
                client_socket.send(input_data.upper().encode())
            print('response sent')
            time.sleep_ms(100)                
            client_socket.close() 
            print('socket closed')

wfs = WifiServer()
wfs.start_server()

