import network
import time
import os
printer = not 'serial' in os.listdir()





def parse_wifi_logins():
    wifi_dict = {}
    with open('wifi_utils/wifi_logins.txt', 'r') as f:
        for line in f:
            ssid, password = line.strip().split(',')
            wifi_dict[ssid] = password
    return wifi_dict




def connect_to_wifi():
    # Initialize the WiFi interface
#     network.hostname('sensorhub0')
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    time.sleep_us(1000)
    # read hostname string from a file hostname.txt, strip it and set it
    try:
        with open('hostname.txt', 'r') as f:
            hostname = f.read().strip()
            wlan.config(dhcp_hostname=hostname)
    except Exception:
        hostname = 'sensorhub0'
        wlan.config(dhcp_hostname=hostname)
#     wlan.config(dhcp_hostname='sensorhub0')
    # Scan for available networks
    if printer: print('scanning for wireless networks...')
    networks = wlan.scan()
#     network.hostname('sensorhub0')
#     wlan.config(dhcp_hostname='sensorhub0')

    # Sort networks by signal strength (network[3])
    networks.sort(key=lambda x: x[3], reverse=True)

    # Load the SSID:password dictionary
    wifi_logins = parse_wifi_logins()

    # Try to connect to each network in order
    for net in networks:
        ssid = net[0].decode('utf-8')
        if ssid in wifi_logins:
            password = wifi_logins[ssid]
            if printer: print('Trying to connect to', ssid)
            wlan.connect(ssid, password)

            # Wait for it to connect
            for i in range(10):
                if wlan.isconnected():
                    if printer: print('Connected to', ssid)
#                     network.hostname('sensorhub0')
#                     wlan.config(dhcp_hostname='sensorhub0')

                    return True
                time.sleep(1)
            if printer: print('Failed to connect to', ssid)

    # If it gets here, it failed to connect to any network
    if printer: print('Failed to connect to any network')
    return False



