from wifi_utils import wifi_login_at_startup as wlas
import time

wlas.connect_to_wifi()
time.sleep(1)

# import webrepl    # type: ignore
# webrepl.start()
# print('webrepl started')
# 
# for i in range(2):  # time to connect with webREPL and interrupt
#     print('waiting 10 seconds to allow webREPL interrupt...',5*(i+1))
#     time.sleep(5)
    

